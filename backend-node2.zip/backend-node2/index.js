const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const app = express()

app.use(bodyParser.json())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))

mongoose.connect('mongodb://192.168.1.2:27017/mydb')

var db = mongoose.connection;

db.on('error',()=>console.log("Error Connection to Database"))
db.once('open',()=>console.log("Connected to Database"))

app.post("/signin",(req,res)=>{
    var name = req.body.name;
    var email = req.body.email;
    var password = req.body.password;

    var data = {
        "email":email,
        "password":password
    }

    db.collection('users').findOne({email:email},(err,user)=>{
        if(err){
            console.log("Erro occured", err);
        }else{
            if(user && user.password === password){
                return res.redirect("signup_success.html");
            }else{
                console.log("Invalide email or password")
            }
        }
    })

})

app.post("/signup",(req,res)=>{
    var name = req.body.name;
    var email = req.body.email;
    var password = req.body.password;

    var data = {
        "name":name,
        "email":email,
        "password":password
    }

    db.collection('users').insertOne(data,(err,collection)=>{
        if(err){
            throw err;
        }
        console.log("Record inserted successfully")
    })

    return res.redirect('signup_success.html')
})


app.get("/",(req,res)=>{
    return res.redirect("index.html");
}).listen(3000);

console.log("Listening on port 3000")