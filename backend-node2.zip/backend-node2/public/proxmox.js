const axios = require('axios');
const https = require('https');

const proxmoxBaseUrl = 'https://192.168.1.3:8006/api2/json';
const proxmoxNode = 'proxmox'; // Replace 'proxmox' with the actual node name
const proxmoxUser = 'root@pam';
const proxmoxPassword = 'amarnath';

const createContainer = async (vmid) => {
  try {
    // Step 1: Create a new container using basic authentication
    const createResponse = await axios.post(
      `${proxmoxBaseUrl}/nodes/${proxmoxNode}/qemu`, // Use the correct endpoint for creating a container
      {
        vmid: vmid,
        ostype: 'l26', // Adjust the OSType as needed
        // Add other container configuration options here
      },
      {
        auth: {
          username: proxmoxUser,
          password: proxmoxPassword,
        },
        httpsAgent: new https.Agent({ rejectUnauthorized: false }), // Disable SSL verification
      }
    );

    console.log(`Container ${vmid} created successfully.`);
  } catch (error) {
    console.error('Error creating container:', error.message);
  }
};

createContainer(300);
